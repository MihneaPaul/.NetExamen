﻿using curs_2_webapi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs_2_webapi.ViewModels
{
    public class PackageGetModel
    {
        public string OriginCountry { get; set; }
        public string Sender { get; set; }
        public string DestinationCountry { get; set; }
        public string Recipient { get; set; }
        public string RecipientAddress { get; set; }
        public double Cost { get; set; }
        public string TrackingCode { get; set; }

        public static PackageGetModel FromPackage(Package package)
        {
            return new PackageGetModel
            {
                OriginCountry = package.OriginCountry,
                Sender = package.Sender,
                DestinationCountry = package.DestinationCountry,
                Recipient = package.Recipient,
                RecipientAddress = package.RecipientAddress,
                Cost = package.Cost,
                TrackingCode = package.TrackingCode
            };
        }
    }
}
