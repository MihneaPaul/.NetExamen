﻿namespace curs_2_webapi.Services
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}