﻿using curs_2_webapi.Models;
using curs_2_webapi.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs_2_webapi.Services
{
    public interface IPackageService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        PaginatedList<PackageGetModel> GetAll(int page);
        Package GetById(int id);
        Package Create(PackagePostModel package, User addedBy);
        Package Upsert(int id, Package package);
        Package Delete(int id);
        IQueryable<PackageGetModel> GetPackagesByOwnerId(int id);
        Dictionary<string, double> GetRecipientsOrderedByCost();
    }
    public class PackageService : IPackageService
    {
        private FlowersDbContext context;
        public PackageService(FlowersDbContext context)
        {
            this.context = context;
        }

        public Package Create(PackagePostModel package, User addedBy)
        {
            Package toAdd = PackagePostModel.ToPackage(package);
            //.Owner = addedBy;
            context.Package.Add(toAdd);
            context.SaveChanges();

            return toAdd;
        }


        //public PaginatedList<PackageGetModel> GetAll(int page, DateTime? from = null, DateTime? to = null)
        //{

        //}
        public Package Delete(int id)
        {
            var existing = context.Package
                .Include(p => p.Owner)
                .FirstOrDefault(package => package.Id == id);
            if (existing == null)
            {
                return null;
            }
            context.Package.Remove(existing);
            context.SaveChanges();

            return existing;
        }

        public PaginatedList<PackageGetModel> GetAll(int page)
        {
            IQueryable<Package> result = context
               .Package
               .OrderBy(f => f.Id)
               .Include(f => f.Owner);
            PaginatedList<PackageGetModel> paginatedResult = new PaginatedList<PackageGetModel>();
            paginatedResult.CurrentPage = page;

            paginatedResult.NumberOfPages = (result.Count() - 1) / PaginatedList<PackageGetModel>.EntriesPerPage + 1;
            result = result
                .Skip((page - 1) * PaginatedList<PackageGetModel>.EntriesPerPage)
                .Take(PaginatedList<PackageGetModel>.EntriesPerPage);
            paginatedResult.Entries = result.Select(p => PackageGetModel.FromPackage(p)).ToList();

            return paginatedResult;
        }

        public Package GetById(int id)
        {
            return context.Package
                .Include(p => p.Owner)
                .FirstOrDefault(p => p.Id == id);
        }

        public Package Upsert(int id, Package package)
        {
            var existing = context.Package.AsNoTracking().FirstOrDefault(p => p.Id == id);
            if (existing == null)
            {
                package.Id = 0;
                context.Package.Add(package);
                context.SaveChanges();
                return package;
            }
            package.Id = id;
            context.Package.Update(package);
            context.SaveChanges();
            return package;
        }

        public IQueryable<PackageGetModel> GetPackagesByOwnerId(int id)
        {
            var packages = context.Package.Where(p => p.Owner.Id == id).Select(p => PackageGetModel.FromPackage(p));
            if(packages == null)
            {
                return null;
            }
            return packages;
        }

        public Dictionary<string,double> GetRecipientsOrderedByCost()
        {
            //var recipients = context.Package.GroupBy(p => p.Recipient).Select(group => group.Sum(item => item.Cost));

            return context.Package.GroupBy(r => r.Recipient)
                             .ToDictionary(c => c.Key, c => c.Sum(s => s.Cost));


        }
    }
}
