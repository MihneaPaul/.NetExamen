﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs_2_webapi.Models
{
    public class Package
    {
        public int Id { get; set; }
        public string OriginCountry { get; set; }
        public string Sender { get; set; }
        public string DestinationCountry { get; set; }
        public string Recipient { get; set; }
        public string RecipientAddress { get; set; }
        public double Cost { get; set; }
        public string TrackingCode { get; set; }
        public User Owner { get; set; }
    }
}
