﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace curs_2_webapi.Migrations
{
    public partial class AddUserCascadeDeletes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Flowers_Users_OwnerId",
                table: "Flowers");

            migrationBuilder.AddForeignKey(
                name: "FK_Flowers_Users_OwnerId",
                table: "Flowers",
                column: "OwnerId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Flowers_Users_OwnerId",
                table: "Flowers");

            migrationBuilder.AddForeignKey(
                name: "FK_Flowers_Users_OwnerId",
                table: "Flowers",
                column: "OwnerId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
