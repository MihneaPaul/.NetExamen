﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using curs_2_webapi.Models;
using curs_2_webapi.ViewModels;
using static curs_2_webapi.Services.PackageService;
using Microsoft.AspNetCore.Authorization;
using curs_2_webapi.Services;

namespace curs_2_webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PackagesController : ControllerBase
    {
        private readonly FlowersDbContext _context;
        private IPackageService _packageService;
        private IUsersService _usersService;
        public PackagesController(IPackageService packageService, FlowersDbContext context, IUsersService usersService)
        {
            _context = context;
            _packageService = packageService;
            _usersService = usersService;
        }

        [Authorize(Roles = "Admin,Regular,UserManager")]
        [HttpGet]
        public PaginatedList<PackageGetModel> Get([FromQuery]int page = 1)
        {
            page = Math.Max(page, 1);
            return _packageService.GetAll(page);
        }

        // GET: api/Packages
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<Package>>> GetPackage()
        //{
        //    return await _context.Package.ToListAsync();
        //}

        // GET: api/Packages/5
        [Authorize(Roles = "Admin,Regular,UserManager")]
        [HttpGet("{id}")]
        public IActionResult GetPackage(int id)
        {
            var package = _packageService.GetById(id);

            if (package == null)
            {
                return NotFound();
            }

            return Ok(package);
        }

        // PUT: api/Packages/5
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPackage(int id, [FromBody] Package package)
        {
            var result = _packageService.Upsert(id, package);
            return Ok(result);
        }

        // POST: api/Packages
        [Authorize(Roles = "Admin,UserManager")]
        [HttpPost]
        public void PostPackage(PackagePostModel package)
        {
            //User addedBy = _usersService.GetCurrentUser(HttpContext);
            //if (addedBy.UserRole == UserRole.UserManager)
            //{
            //    return Forbid();
            //}
            _packageService.Create(package,null);
        }

        // DELETE: api/Packages/5
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public IActionResult DeletePackage(int id)
        {
            var result = _packageService.Delete(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        private bool PackageExists(int id)
        {
            return _context.Package.Any(e => e.Id == id);
        }

        [HttpGet("ownedby")]
        public IActionResult GetPackagesByOwnerId(int id)
        {
            var result = _packageService.GetPackagesByOwnerId(id);
            if(result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpGet("orderedbycost")]
        public IActionResult GetRecipientsOrderedByCost()
        {
            var result = _packageService.GetRecipientsOrderedByCost();
            if (result == null) return NotFound();

            return Ok(result);
        }
    }
 }

