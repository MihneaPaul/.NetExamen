﻿using curs_2_webapi.Models;
using curs_2_webapi.Services;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace WebApiTests
{
    class FlowersServiceTest
    {
        [Test]
        public void UpsertShouldUpdateExistingFlower()
        {
            var options = new DbContextOptionsBuilder<FlowersDbContext>()
              .UseInMemoryDatabase(databaseName: nameof(UpsertShouldUpdateExistingFlower))
              .Options;

            using (var context = new FlowersDbContext(options))
            {
                var flowerService = new FlowerService(context);
                var addedFlower = flowerService.Create(new curs_2_webapi.ViewModels.FlowerPostModel
                {
                    Colors = "fdsfsd",
                    DatePicked = new DateTime(),
                    Comments = new List<Comment>()
                    {
                        new Comment
                        {
                            Important = true,
                            Text = "asd",
                            Owner = null
                        }
                    },
                    FlowerSize = "large",
                    Name = "fdsfds",
                    IsArtificial = false,
                    SmellLevel = 2
                }, null);

                context.Entry(addedFlower).State = EntityState.Detached;
                Assert.AreEqual("fdsfds", addedFlower.Name);
                addedFlower.Name = "updated flower";
                var updatedFlower = flowerService.Upsert(addedFlower.Id, addedFlower);
                Assert.AreEqual("updated flower", updatedFlower.Name);
            }
        }

    }
}
